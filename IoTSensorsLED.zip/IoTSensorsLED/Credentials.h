/*
#define  WIFIssid        "???????"
#define  WIFIpassword    "???????"

#define  OTA_password    "???????"



#define  WIFIssid        "????"
#define  WIFIpassword    "????"
#define  OTA_password    "????"

#define IO_USERNAME      "????????"
#define IO_KEY           "***************************"
#define MQTT_SERVER      "io.adafruit.com"
#define MQTT_SERVERPORT  1883
#define MQTT_LUX         "????????/feeds/lux"
#define MQTT_AirTemp     "????????/feeds/airtemp"
#define MQTT_Humidity    "????????/feeds/humidity"
#define MQTT_Led         "????????/feeds/led"
#define MQTT_Pump        "????????/feeds/pump"
#define MQTT_Upgrade     "????????/feeds/upgrade"
*/

#define  WIFIssid        "BILLYWIFI"
#define  WIFIpassword    "Xolmem13"

#define  OTA_password    "Xolmem18"


#define IO_USERNAME           "dwong"
#define IO_KEY                "a52d93d0a1aa42e09850009bcb472012"
#define MQTT_SERVER           "io.adafruit.com"
#define MQTT_SERVERPORT       1883
#define MQTT_LUX              "dwong/feeds/lux"
#define MQTT_EC               "dwong/feeds/ec"
#define MQTT_AirTemp          "dwong/feeds/airtemp"
#define MQTT_Humidity         "dwong/feeds/humidity"
#define MQTT_Led              "dwong/feeds/led"
#define MQTT_LedOnHour        "dwong/feeds/ledonhour"
#define MQTT_LedOffHour       "dwong/feeds/ledoffhour"
#define MQTT_Pump             "dwong/feeds/pump"
#define MQTT_PumpOnInterval   "dwong/feeds/pumponmin"
#define MQTT_PumpOffInterval  "dwong/feeds/pumpoffmin"
#define MQTT_Upgrade          "dwong/feeds/upgrade"
